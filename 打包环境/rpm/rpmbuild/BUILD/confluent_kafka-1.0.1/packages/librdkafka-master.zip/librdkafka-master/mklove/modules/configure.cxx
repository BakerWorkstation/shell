#!/bin/bash
#
# C++ detection
#
# This script simply limits the checks of configure.cc


MKL_CC_WANT_CXX=1
