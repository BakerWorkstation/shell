#ifndef __RDMURMUR2___H__
#define __RDMURMUR2___H__

uint32_t rd_murmur2 (const void *key, size_t len);
int unittest_murmur2 (void);

#endif // __RDMURMUR2___H__
